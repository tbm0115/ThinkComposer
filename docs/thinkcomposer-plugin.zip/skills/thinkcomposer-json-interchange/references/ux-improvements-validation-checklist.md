# UX Improvements Validation Checklist

Use this checklist before calling the `feature/UXImprovements` layout work stable for a build or pull request.

For `feature/DcomInterchange`, also run the Domain JSON and embedded-domain checks below before release.

## General

- [ ] Build `ThinkComposer/ThinkComposer.csproj` with Debug configuration.
- [ ] Open an existing composition and confirm `Edit -> Appearance` contains the route and layout commands.
- [ ] Confirm each command writes useful detail to the lower-left application log.
- [ ] Confirm every visual mutation is undoable and redoable.
- [ ] Save, close, reopen, and confirm layout changes persist.
- [ ] Export PDF/report and confirm visuals render.

## Fit Concept Width to Text

- [ ] Select one short-label concept and run `Edit -> Appearance -> Fit Concept Width to Text`.
- [ ] Select one long-label concept and run the command.
- [ ] Select multiple concepts and run the command.
- [ ] Select relationship symbols/complements and confirm they are skipped safely.
- [ ] Double-click left/right resize handles and confirm auto-fit runs without breaking normal drag resize.
- [ ] Undo and redo.

## Route Links with Obstacle Avoidance

- [ ] Open `Test__Object_Avoidance.tcom`.
- [ ] Import `samples/obstacle-avoidance-regression.sample.json` if needed.
- [ ] Route Scenario A and confirm deterministic routing around the obstacle.
- [ ] Route Scenario B and confirm a legible multi-bend route around same-row/same-column blocking.
- [ ] Route Scenario C and confirm clear paths remain straight or are straightened.
- [ ] Run with no selected links and confirm the all-visible prompt appears.
- [ ] Undo and redo.
- [ ] Save, reopen, and export PDF/report.

## Multi-Point Routes And Manual Editing

- [ ] Migrate an old binary containing null and singleton `IntermediatePosition` values; confirm they become zero and one route point without changing appearance.
- [ ] Export/re-import Composition JSON v1 and confirm `intermediatePosition` migrates to a singleton route.
- [ ] Round-trip Composition JSON v2 connectors with zero, one, and many `routePoints`; confirm `[]` clears while omission in a patch preserves the route.
- [ ] Supply both fields and confirm `routePoints` wins with a warning.
- [ ] Attempt nonfinite and 33-point updates and confirm they are rejected rather than truncated.
- [ ] Clone and paste a connector, mutate the copy, and confirm its route collection is independent.
- [ ] Drag indexed bend handles, drag segment-midpoint handles to insert/shift bends, and double-click a bend to remove it.
- [ ] Exercise `Edit Route`, `Remove Bend`, `Simplify Route`, `Straighten Route`, and `Auto-route`.
- [ ] Confirm hidden simple Relationships expose one logical editable route across both connector halves.
- [ ] Undo/redo every insert, update, remove, clear, translate, simplify, straighten, and auto-route edit.
- [ ] Confirm the rendered path is continuous, plugs follow the first/last nonzero segment, and role labels choose a usable central/long segment.
- [ ] Confirm automatic right-angled paths use capped six-unit rounded corners, while migrated legacy `SinglelineStraight`/`SinglelineCurved` paths remain sharp free-angle polylines.

## Routing Scope And Determinism

- [ ] Move one symbol and confirm only incident links reroute; unrelated hand-routed links remain byte-for-byte unchanged.
- [ ] Move an entire connected selection by one delta and confirm its complete routes translate intact.
- [ ] Move one endpoint of a route with a distant stale bend and confirm the stale geometry is never restored.
- [ ] Route the same fixture repeatedly and under reversed connector enumeration; confirm identical output.
- [ ] Confirm visible Relationship hubs are obstacles in Route Links, Spider, Hierarchy, Flowchart, and System Map.
- [ ] Confirm binary hubs remain inside endpoint corridors and multi-endpoint hubs use a local centroid/median star.
- [ ] Confirm Flowchart feedback lanes remain mandatory waypoints/corridors.
- [ ] Force work-cap exhaustion and confirm a safe outer/direct fallback plus an explicit diagnostic.
- [ ] Run `composition validate-routing` with `route`, `spider`, `hierarchy`, `flowchart`, and `system`; inspect before/after route JSON, diagnostics, and PNGs.
- [ ] Save/reopen each result and confirm finite/local points, idempotence, and unchanged unrelated connectors.

## Spider Map

- [ ] Open `Test__Spider_Map.tcom`.
- [ ] Import `samples/spider-map-regression.sample.json` if needed.
- [ ] Deselect everything and run `Edit -> Appearance -> Arrange as Spider Map`.
- [ ] Confirm the all-visible prompt appears.
- [ ] Confirm the chosen root is central and connected concepts are radial.
- [ ] Confirm no arranged concept is above or left of the reachable canvas origin.
- [ ] Confirm links route after movement.
- [ ] Undo, redo, save/reopen, and export PDF/report.

## Hierarchy Map

- [ ] Open `Test__Hierarchy_Map.tcom`.
- [ ] Import `samples/hierarchy-map-regression.sample.json` if needed.
- [ ] Deselect everything and run `Edit -> Appearance -> Arrange as Hierarchy Map`.
- [ ] Confirm roots appear at the top and children/second-level concepts appear below.
- [ ] Confirm disconnected components are separated.
- [ ] Confirm visible relationship bubbles do not overlap each other or concepts in the target regression cases.
- [ ] Confirm local relationship bubbles stay near their endpoint corridor.
- [ ] Confirm links route after relationship-bubble movement.
- [ ] Undo, redo, save/reopen, and export PDF/report.

## Flowchart

- [ ] Open `Test__Flowchart.tcom`.
- [ ] Import `samples/flowchart-regression.sample.json` if needed.
- [ ] Deselect everything and run `Edit -> Appearance -> Arrange as Flowchart`.
- [ ] Confirm starts appear on the left and downstream steps flow left-to-right.
- [ ] Confirm branches are vertically separated.
- [ ] Confirm feedback/reverse/cross-link bubbles use an outer lane.
- [ ] Confirm the Error Feedback relationship does not overlap the Invalid concept or Invalid To Error bubble.
- [ ] Confirm forward links remain readable and routed.
- [ ] Undo, redo, save/reopen, and export PDF/report.

## System Map

- [ ] Open `Test__System_Map.tcom`.
- [ ] Import `samples/system-map-regression.sample.json` if needed.
- [ ] Deselect everything and run `Edit -> Appearance -> Arrange as System Map`.
- [ ] Confirm Deployment Manager System is selected as root/header.
- [ ] Confirm Web App, Package Catalog, Job Orchestrator, Configuration Manager, and Audit Log are comfortably inside the Group Region.
- [ ] Confirm User and Package Source are outside left, and Host Agent and OT Network Endpoint are outside right.
- [ ] Confirm the Group Region is visible, behind concepts, and does not alter semantic containment.
- [ ] Confirm Package Source To Catalog does not overlap User.
- [ ] Confirm User To Web App, Package Source To Catalog, and Web App To Audit Log do not overlap each other.
- [ ] Confirm links cross the Group Region boundary cleanly.
- [ ] Undo, redo, save/reopen, and export PDF/report.

## JSON Import Visual Cleanup

- [ ] Confirm root `/Composition.json` rehydrates as an exact snapshot and does not execute `importOptions` or `visualStrategy`.
- [ ] Load a legacy root containing `operations[]`; confirm snapshot rehydration occurs first, operations apply once through the importer, and the Composition becomes dirty so save consumes the directives.
- [ ] Place/update an existing representation using `representationId` plus view; confirm position/size updates and incident-link invalidation.
- [ ] Import a patch that creates concepts with long names and confirm `autoFitPlacedConcepts` fits newly placed concept widths.
- [ ] Confirm existing concepts that are only text-updated are not resized unless operation `autoFit: true` is set.
- [ ] Confirm operation `autoFit: false` suppresses fitting for that operation.
- [ ] Import a patch with newly placed relationships and confirm `autoRoutePlacedLinks` routes touched links only.
- [ ] Confirm pre-existing unrelated links are not routed by JSON import.
- [ ] Confirm operation `autoRoute: false` suppresses routing for that operation.
- [ ] Confirm operation `visual.relationshipCenterPlacement` overrides global placement for the touched Relationship.
- [ ] Confirm generated Relationship operations default to `endpointCorridor` and `autoRoute:true`, and reject implicit explicit hub coordinates.
- [ ] Confirm GPT-authored `routePoints` are rejected/warned by default; generated patches request routing instead.
- [ ] Undo import and confirm concept widths and connector routes revert.
- [ ] Save, reopen, and export PDF/report.

## Composition JSON Description, TechSpec, And Details

- [ ] Export a `.tcom` JSON file from a composition that has Description and TechSpec on the composition, concepts, relationships, views, or definitions.
- [ ] Confirm exported JSON includes `description` where values exist.
- [ ] Confirm exported JSON includes `techSpec` where values exist.
- [ ] Import `samples/json-interchange-regression.sample.json` after adapting tech names to the active composition.
- [ ] Confirm `set.description` updates an existing object and logs the field-level update.
- [ ] Confirm `set.techSpec` updates an existing concept and logs the field-level update.
- [ ] Import `samples/composition-description-details-regression.sample.json` into a blank All-Purpose composition.
- [ ] Confirm description and TechSpec line breaks persist for composition, concepts, and relationships.
- [ ] Open an imported concept's Properties dialog and confirm the Description tab opens without a XAML parse error.
- [ ] Confirm known-field Text details can update Description through `targetPropertyTechName=Description`.
- [ ] Confirm unsupported free-form details append to Description when `detailFallbackMode=appendToDescription`.
- [ ] Save, reopen, and confirm Description and TechSpec persist.

## Composition JSON Fixture Imports

- [ ] Create a fresh composition such as `Composition1`.
- [ ] Import `samples/composition-active-root-fallback.sample.json`.
- [ ] Confirm the preview/apply summary creates 2 concepts and 1 relationship, with `Skipped: 0`.
- [ ] Confirm the log includes `JSON import container fallback: requested='Active_Composition_Root'` and an active/root view fallback because the sample omits `viewTechName`.
- [ ] Import each layout fixture sample that declares `importOptions.useActiveCompositionAsContainer=true`.
- [ ] Confirm create counts are greater than zero and root-level fixture containers fall back to the active composition.
- [ ] Confirm the log includes `JSON import container fallback` for samples whose `containerTechName` names a missing `Test__...` composition.
- [ ] Run the matching Appearance layout command for each imported fixture.
- [ ] Confirm samples without the fallback still explain which `containerId`/`containerTechName` values must be replaced before import.
- [ ] For `machine_monitoring_utilization_productivity_composition.json`, update the companion MTConnect Domain in the target package first, then apply the composition patch.
- [ ] Confirm the generated MTConnect patch previews 20 concept creates and 34 relationship creates, with no missing-container skips for `Active_Composition_Root`.
- [ ] Confirm any remaining skips are specific definition, endpoint, role, view, or detail issues rather than container fallback failures.
- [ ] Confirm relationship compatibility skips include endpoint concept definitions, resolved roles, allowed endpoint definitions when available, and a grouped summary by relationship definition.
- [ ] Confirm relationship compatibility failures emit a copyable `BEGIN THINKCOMPOSER RELATIONSHIP COMPATIBILITY REPORT` block in the lower-left log.
- [ ] Import `samples/composition-strict-domain-compatibility.sample.json` into an All-Purpose composition and confirm strict relationship preflight passes with zero compatibility skips.
- [ ] Change the strict sample's `requires.domain.techName` or use a mismatched active domain and confirm `domainCompatibilityPolicy=requireTechName` blocks before apply.
- [ ] Add strict options to the current machine-monitoring generated patch and confirm `strictRelationshipCompatibility=true` plus `abortOnRelationshipCompatibilityFailure=true` blocks before concepts/relationships are created when compatibility failures exist.
- [ ] Import a latest-Skill-generated full-state-style composition JSON without `treatMissingFullStateItemsAsCreates` and confirm the dialog/log explains that missing top-level ideas/relationships were treated as updates, not creates.
- [ ] Import `samples/composition-full-state-create.sample.json` into a blank All-Purpose composition and confirm concepts created=2, relationships created=1, visuals placed > 0, skipped=0.
- [ ] Import `samples/composition-description-details-regression.sample.json` into a blank All-Purpose composition and confirm first-class descriptions, TechSpec, and detail fallback behavior apply without skipping created ideas.
- [ ] Import `samples/composition-shortcut-roundtrip.sample.json` into a blank All-Purpose composition and confirm one semantic concept appears twice in the same view, with the second visual marked as a Shortcut.
- [ ] Export/re-import the shortcut sample and confirm `isShortcut:true` persists and no duplicate semantic concept is created.
- [ ] Add `treatMissingFullStateItemsAsCreates=true` to the generated full-state machine-monitoring JSON and confirm concepts are created instead of skipped; relationships either create or report relationship compatibility failures.
- [ ] Import `samples/composition-large-visual-strategy.sample.json` into a blank All-Purpose composition and confirm `visualStrategy.mode=modelOnly` creates semantic concepts/relationships while suppressing visual placement, auto-fit, auto-route, and immediate view refresh.
- [ ] Change the same sample to `visualStrategy.mode=overviewAndModel` and confirm only the capped overview visuals are planned/applied while the semantic model still imports.
- [ ] For large generated composition JSON, confirm GPT-generated files use `visualStrategy` instead of hand-placing/routing hundreds or thousands of objects by default.
- [ ] Import `samples/composition-relationship-center-placement.sample.json` and confirm relationship centers originally placed in a top/global band are recomputed near their source/target endpoint corridors when `relationshipVisualPlacementMode=auto`.
- [ ] Re-import the same sample with `relationshipVisualPlacementMode=explicit` and confirm the intentionally bad relationship center positions are preserved.
- [ ] Run Edit -> Appearance -> Route Links with Obstacle Avoidance and confirm the dialog reports relationship centers inspected/recomputed before routing.
- [ ] Import `samples/composition-intent-agnostic-groups.sample.json` and confirm a Group Region is created only because `groups[].createGroupRegion=true`, the membership relationship is hidden only because `visual.display=hidden`, and the visible dependency relationship remains visible.
- [ ] Import `samples/composition-intent-agnostic-visual-controls.sample.json` and confirm the summary concept is visible, the deferred concept is semantic-only/no visual, the dependency relationship center is corrected near endpoints, and the diagnostic relationship is excluded from routing because of explicit JSON metadata.
- [ ] Confirm no source-specific inference appears in the log; decisions should say `reason=explicit JSON metadata` or use generic visual/layout option names.
- [ ] In a composition with duplicate-looking concepts, right-click a non-shortcut concept visual, run `Replace with Shortcut...`, choose an existing target concept, and confirm only that visual is replaced by a shortcut.
- [ ] Confirm visible current-view relationships touching the replaced visual are reassigned to the shortcut target, while other visuals/metadata on the source concept remain.
- [ ] Try `Replace with Shortcut...` with a target concept that violates a visible relationship definition and confirm the command blocks without partial changes.
- [ ] Import `samples/composition-relationship-fallback.sample.json` in a domain that has the requested strict relationship definition and generic `Relationship` fallback, or read its warning notes when the strict definition is unavailable.
- [ ] Confirm `relationshipDefinitionFallbackTechName` is never used silently: fallback is logged, and `strictDefinition: true` prevents fallback.
- [ ] Import a patch with `set.details` using a missing native detail designator and `detailFallbackMode=appendToTechSpec`; confirm the idea is still created and the detail text/rows are appended to TechSpec with a clear delimiter.

## Domain JSON Interchange

- [ ] Open or create a `.tdom`.
- [ ] Inspect root `/Domain.json`.
- [ ] Confirm root Domain JSON includes `domain.compatibilitySignature` and a `relationshipCompatibility` section when relationship definitions are present.
- [ ] Apply `samples/domain-json-interchange-patch.sample.json` through direct root `/Domain.json` patching or the CLI compatibility import path.
- [ ] If using the CLI import path, confirm the preview lists planned creates/updates and dangerous skipped deletes.
- [ ] Confirm domain summary/TechSpec updates, and new definitions/tables/fields/templates are created when dependencies exist.
- [ ] Confirm output template text is preserved as text and never executed.
- [ ] Apply `samples/domain-json-metadata-update.sample.json` through direct root `/Domain.json` patching or the CLI compatibility import path.
- [ ] Confirm field-level log lines include domain `summary`/`techSpec` and externalLanguage `summary`/`techSpec`, including match method.
- [ ] Confirm metadata patch result is 2 updates, 0 skips, 0 source warnings, 0 import warnings, and 0 errors after adapting the external language techName if needed.
- [ ] Save/reopen, inspect root `/Domain.json`, and verify `domain.techSpec` plus the target `externalLanguages[]` summary/TechSpec persisted.
- [ ] Apply `samples/domain-json-additive-definition.sample.json` through direct root `/Domain.json` patching or the CLI compatibility import path.
- [ ] Confirm additive patch result is 5 creates, 0 skips, 0 source warnings, 0 import warnings, and 0 errors on a fresh test copy.
- [ ] Confirm additive table, fields, concept definition, and output template are created without destructive changes.
- [ ] Confirm field logs show parent table and data type resolution, and template logs show owner scope/owner/language resolution.
- [ ] Save, reopen, and confirm changes persist.

## Output Template Generation

- [ ] Baseline repro: open a composition using a domain with concept/relationship output templates, do not open any Concept/Relationship Definition dialogs, run `Tools -> Output -> Generate Files...`, and confirm generation succeeds or reports only real missing templates/languages/subtemplates.
- [ ] Refresh command: run `Tools -> Output -> Refresh Output Templates` and confirm the dialog reports concept definitions inspected, relationship definitions inspected, templates prepared, warnings, and errors without generating files.
- [ ] Preview scope: clear the selection, run `Tools -> Output -> Generation Preview`, and confirm preview uses the active composition/root scope instead of being disabled.
- [ ] Effective template: select one concept or relationship, run `Generation Preview`, and confirm the preview window shows `Rendered Output`, `Effective Template`, and `Resolution` tabs.
- [ ] Resolution metadata: confirm preview shows target name/techName/id/kind, selected external language, template owner scope/techName, template role, template hash, generated filename, and validation notes.
- [ ] Generate files: confirm each generated file logs `Output template resolution` with file path, source item, language, owner scope, template hash, role, and validation result.
- [ ] Subtemplates: confirm the log contains `Output template subtemplates registered` entries and that explicit Fragment/SubTemplate templates are not emitted as standalone deliverables by default.
- [ ] Validation: generate XML-like or JSON-like output and confirm the summary reports XML/JSON valid/invalid counts without crashing generation.
- [ ] Save/reopen: update Domain JSON containing output templates, save the composition, close/reopen, generate composition output, and confirm no individual Output-Templates tabs need to be opened.
- [ ] MTConnect case: open the MTConnect Machine Monitoring composition, update the companion MTConnect Domain from `.tdom`, and generate an MTConnectDevices, SHACL, Mermaid, Text, or Use-Case Proposal output if available.
- [ ] Confirm the lower-left log contains `Output template preparation started`, active composition/domain/language context, inspected counts, materialized template counts, lint counts, and per-template warnings/errors.
- [ ] Confirm output templates are not executed during Domain JSON compatibility import/export or refresh-only preparation.

## Embedded Domain Update

- [ ] Open an older `.tcom` composition.
- [ ] Run `Composition -> Domain -> Update Embedded Domain...`.
- [ ] Select a newer `.tdom`.
- [ ] Confirm the preview lists added/updated/legacy-retained domain objects.
- [ ] Confirm source warnings, import warnings, skipped operations, dangerous skipped operations, and errors are listed separately.
- [ ] Confirm preserved source/export warnings do not make a clean update look like a failed import.
- [ ] Apply and confirm existing composition ideas remain intact.
- [ ] Confirm new definitions/templates/tables appear in palettes/domain-dependent UI where supported.
- [ ] Undo/redo if practical.
- [ ] Save, reopen, and confirm the embedded domain update persists.

## AI-Readable Container Snapshots

- [ ] Save a `.tcom` and inspect it as a package/zip.
- [ ] Confirm `/manifest.json`, `/Composition.json`, `/Domain.json`, `/Interchange/Composition.json`, `/Interchange/Domain.json`, `/Interchange/manifest.json`, and one or more `/Previews/views/*.png` entries exist when the composition has renderable views; confirm `/Composition.bin` does not exist.
- [ ] Parse `/manifest.json` and confirm `packageKind: composition`, `persistenceFormat: json`, authoritative part metadata, and `legacyBinaryFallback.present: false` with no binary URI/hash.
- [ ] Parse `/Interchange/manifest.json`, `/Interchange/Composition.json`, and `/Interchange/Domain.json` with `ConvertFrom-Json`.
- [ ] Confirm `/Interchange/manifest.json` uses `formatVersion: 2`, points `nativePartUri` to the authoritative root JSON part, and records `inputSha256`, `renderProfile`, and `disposition` for each preview.
- [ ] Open the saved `.tcom` normally and confirm load behavior uses root `/Composition.json` without requiring the sidecar JSON or binary fallback.
- [ ] Save a `.tdom` without a template composition and confirm `/manifest.json`, `/Domain.json`, `/Interchange/Domain.json`, and `/Interchange/manifest.json` exist, `/Domain.bin` does not, and template composition sidecars are skipped as a manifest/log warning.
- [ ] Save a `.tdom` with the template composition option enabled and confirm `/Interchange/TemplateComposition.json` and any safe template view previews are present.
- [ ] For a large composition, confirm preview generation is capped/skipped safely and save still succeeds with sidecar warnings rather than failing the native save.
- [ ] Save an unchanged package twice and confirm the second manifest reports `disposition: reused` with byte-identical PNG hashes.
- [ ] Change one view and save again; confirm only that view or a conservatively dependent view is rerendered.
- [ ] Corrupt or remove a cached PNG/manifest entry and confirm ThinkComposer rerenders it instead of copying unverified bytes.
- [ ] Run both JSON persistence validators and confirm their injected required-writer failure preserves the original byte-for-byte while their injected optional-writer failure leaves a readable package with its required payload.

## Large JSON Open Responsiveness and Performance

- [ ] Open large `.tcom` and `.tdom` packages from menu, recent list, startup/command line, and merge paths where applicable.
- [ ] Confirm the independent splash paints promptly, shows the current stage, animates elapsed time during an indeterminate parse, advances item counts during reconstruction, and has no Cancel button.
- [ ] Confirm the splash closes exactly once on success, corrupt JSON, legacy fallback, and no-fallback failure, leaving no orphaned splash thread or partially registered workspace document.
- [ ] Run `thinkcomposer performance prepare-json-persistence-corpus --mode certification` with repository examples, predefined Domains, and at least one sanitized slow package. Confirm every case's whole-package SHA-256 and actual byte length remain locked.
- [ ] Run a one-warmup/five-iteration pre-optimization baseline with `--allow-legacy-baseline-output` when its JSON-authoritative writer retains the exact matching legacy binary fallback; run the candidate without that flag and with `--baseline`. Confirm corpus mode, per-case hashes/sizes, machine fingerprint, and run counts match; every candidate sample is JSON-only; and both aggregate median load and first-save speedups meet `2.0`.
- [ ] Capture baseline/candidate WPR traces around the sanitized slow-package run with CPU, file/disk I/O, allocation/.NET activity, and UI/WPF responsiveness enabled; compare the dominant stages in WPA.

## Documentation and Skill Bundle

- [ ] Parse `docs/thinkcomposer-json-interchange.schema.json` with `ConvertFrom-Json`.
- [ ] Parse `docs/thinkcomposer-domain-json-interchange.schema.json` with `ConvertFrom-Json`.
- [ ] Parse `docs/thinkcomposer-package-manifest.schema.json` with `ConvertFrom-Json`.
- [ ] Parse `docs/thinkcomposer-container-manifest.schema.json` with `ConvertFrom-Json`.
- [ ] Parse every `samples/*.sample.json` file with `ConvertFrom-Json`.
- [ ] Sync the bundled skill references under `docs/thinkcomposer-plugin/skills/thinkcomposer-json-interchange/references/`.
- [ ] Regenerate `docs/thinkcomposer-json-interchange.zip` and `docs/thinkcomposer-plugin.zip` with `docs/thinkcomposer-plugin/scripts/package_thinkcomposer_plugin.py`.
- [ ] List the ZIP contents and confirm `SKILL.md`, `scripts/validate_json.py`, and current references are included without absolute paths.
- [ ] List `docs/thinkcomposer-plugin.zip` contents and confirm `.codex-plugin/plugin.json`, `.mcp.json`, `skills/`, and `scripts/` are included without absolute paths.
